function animatedbutton1(){
  window.location.href="login.html"
}